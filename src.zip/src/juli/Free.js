//белый предпоследний блок
import React from 'react'
import './Free.css'

const styles = {
    div : {
position: 'absolute',
zIndex: 2,
left: 0,
right: 0,
top: '78.67%',
bottom: '0%',
backgroundColor: '#F5F7F9'


    }
}

export default function Free() {
    return (
       <div style= {styles.div} >
            <div class="WhiteBlock1">
            <p class="WhiteBlock1World">Кредиты</p>
            <p class="WhiteBlock1World">Дебетовые карты</p>
            <p class="WhiteBlock1World">Кредитные карты</p>
        </div>
        <div class="WhiteBlock2">
            <p class="WhiteBlock1World">Офисы и банкоматы</p>
            <p class="WhiteBlock1World">Курсы валют</p>
            <p class="WhiteBlock1World">Тарифы</p>

        </div>
            </div> 
    )

}