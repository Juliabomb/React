// Курсы валют
import React from 'react'
import './Six.css'
import logo from './Galka.png'
import path from './Path.png'


const styles = {
    div : {
position: 'absolute',
zIndex: 3,
left: '56.39%',
right: '23.06%',
top: '17.78%',
bottom: '61.78%',
backgroundColor: 'rgba(255, 255, 255, 1)',

borderRadius: '8px'

    }
 
}



export default function Six() {
    return (
       <div style= {styles.div}  > 
       <span className = 'Kurs'>Курсы валют</span> 
        <img src={logo} alt="logo" className ='Galka1'/>
        <div className = 'Curs'>
        <table>
            <tr>
            <th class="tableZ" width="50"> </th>
            <th class="tableZ" width="150">Покупка </th>
            <th class="tableZ">Продажа </th>
            </tr>
            <tr>
            <th class="tableZ0" height = "30"> USD</th>
            <td class="tableX"><img src={path} alt="logo" />  62,75 </td>
            <td class="tableX"><img src={path} alt="logo" />  63,95 </td>
            

            </tr>
            <tr>
            <th class="tableZ0" height = "30"> EUR</th>
            <td class="tableX"> <img src={path} alt="logo" /> 62,75 </td>
            <td class="tableX"><img src={path} alt="logo" /> 63,95 </td>

            </tr>
            <tr>
            <th class="tableZ0" height = "30">GBR </th>
            <td class="tableX"> <img src={path} alt="logo" /> 62,75 </td>
            <td class="tableX"> <img src={path} alt="logo" /> 63,95 </td>
            </tr>

        </table>
        </div> 
         </div> 
    )

}