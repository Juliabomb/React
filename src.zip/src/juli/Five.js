//Вход в интернет банк
import React from 'react'
import './Five.css'
import logo from './view.png'

const styles = {
    div : {
position: 'absolute',
zIndex: 3,
left: '23.06%',
right: '51.94%',
top: '17.78%',
bottom: '35.11%',
backgroundColor: 'rgba(255, 255, 255, 0.8)',

borderRadius: '4px'

    }
 
}




export default function Five() { 
   
	
	
    return (
       <div style= {styles.div} >
            <span className='Vxod'>Вход в Интернет Банк</span> 

            <button class="button-Vxod">Войти</button>

            
       
	
		<input  className = 'Schet' />
        <input  className = 'Schet1'/>
        <span className = 'SchetPodzkazka'>Номер карты или логин</span>
        <span className = 'SchetPodzkazka1'>Пароль</span>
        <span className='SchetNumber'>1234 5678 90|</span>

        {/* <label className ='SchetPodzkazka'>Номер карты или логин</label>
        <label className ='SchetPodzkazka1'>Пароль</label> */}
		
	
          
          
            <img src={logo} alt="logo" className ='eye'/>
            

            <span className='Vxod2'>Востановить логин или пароль</span> 
       </div> 
    )
    

}