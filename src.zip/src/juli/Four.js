//Последний серый блок
import React from 'react'
import './Four.css'
import logo1 from './vk.png'
import logo2 from './Facebook.png'
import logo3 from './Odnok.png'
import logo4 from './Telega.png'
import logo5 from './Copy.png'


const styles = {
    div : {
position: 'absolute',
zIndex: 3,
left: 0,
right: 0,
top: '92%',
bottom: '0%',
backgroundColor: 'rgba(0, 0, 0, 0.6)'

    }
 
}



export default function Four() {
    return (
       <div style= {styles.div} > 
            <span className='Textt'>© 1997 — 2018 Compass Plus</span>
            <span className ='Textt2'>Контактный центр</span>
            <span className = 'Textt3'>8 800 800-00-00</span>
            <div className ='Krug1'> <img src={logo1} alt="logo" className ='logo1' /> </div>
            <div className ='Krug2'> <img src={logo2} alt="logo" className ='logo2' /> </div>
            <div className ='Krug3'> <img src={logo3} alt="logo" className ='logo3' /> <div className = 'pathOdn'/></div>
            <div className = 'Krug4'><div className = 'Instagram1'/><div className = 'Instagram2'/><div className = 'Instagram3'/></div>
            <div className = 'Krug5'><div className = 'Youtube1'/><div className = 'Youtube2'/></div>
            <div className = 'Krug6'><img src={logo4} alt="logo" className ='logo4' /></div>
            <span class="English">English</span> 
            <img src={logo5} alt="logo" className ='English1' />
       </div> 
    )

}