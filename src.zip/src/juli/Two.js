// Верхняя белая полоса
import React from 'react'

import logo from './LogoTitle.jpg';

const styles = {
    div : {
position: 'absolute',
zIndex: 2,
left: 0,
right: 0,
top: '0%',
bottom: '92%',
backgroundColor: '#FFFFFF',
    }
}

const styles2 = {
    img : {
position: 'absolute',
zIndex: 3,
left: '10.28%',
right: '78.61%',
top: '10%',
bottom: '92%',
height: '72px',
Width: '160px', 
    }
}

export default function Two() {
    return (
       <div style= {styles.div} > <img src={logo} alt="logo" style= {styles2.img} /> </div> 
    )
}