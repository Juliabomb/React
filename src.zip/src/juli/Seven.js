// Ипотека
import React from 'react'
import logo from './ipoteca.png'
import './Seven.css'

const styles = {
    div : {
position: 'absolute',
zIndex: 3,
left: '56.39%',
right: '23.06%',
top: '44.44%',
bottom: '35.11%',
backgroundColor: '#FFFFFF',

borderRadius: 8
    }
 
}

const styles2 = {
    img : {
position: 'absolute',
zIndex: 3,
left: '0%',
bottom: '0%',
width: '100%',
height: 110,
borderRadius: '0px 0px 8px 8px'

    }
}

export default function Seven() {
    return (
       <div style= {styles.div} >
         <img src={logo} alt="logo" style= {styles2.img}/> 
         <span className = 'Ipoteca'>Ипотека</span> 
         <p className='Text'>Подайте заявку на ипотеку онлайн и получите одобрение дистанционно.</p>
       </div> 
    )

}