// красная полоса
import React from 'react'

import './One.css'

const styles = {
    div : {
position: 'absolute',
zIndex: 2,
left: 0,
right: 0,
top: '8%',
bottom: '85.78%',
backgroundColor: '#BA1419',
color: 'white'


    }
}

// const span11 = {
//     span11: {
//         position: 'absolute',
//         zIndex: 3,
//         top: '100%',
//         left: '60%'
// }
// }

export default function One() {
    return (
       <div style= {styles.div} > 
           <span className = 'span1'> ВХОД </span> <hr className = 'hr1'/>
           <span className = 'span2'>СОБЫТИЕ </span> 
           <span className = 'span3'> КУРСЫ </span><br></br>
           <span className = 'span33'>ВАЛЮТ</span>
           <span className = 'span4'> ОТДЕЛЕНИЯ И </span>
           <span className = 'span44'>БАНКОМАТЫ</span>
           <span className = 'span5'>КОНТАКТЫ </span> 
       
       
       </div> 
    )

}