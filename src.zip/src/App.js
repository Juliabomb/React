// import logo from './logo.svg';
// import './App.css';

import One from "./juli/One";
import Two from "./juli/Two";
import Free from "./juli/Free";
import Four from "./juli/Four";
import Five from "./juli/Five";
import Six from "./juli/Six";
import Seven from "./juli/Seven";


function App() {
  return (
    
<div className='fon' > 
<One />
<Two />
<Free />
<Four />
<Five />
<Six />
<Seven />


</div>
  )
}

export default App;
